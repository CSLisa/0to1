from django.apps import AppConfig


class PaycomuzConfig(AppConfig):
    name = 'PaycomUz'
